<!--
Jika sudah disi maka akan dibawa menuju halaman
bintang.php, dimana output berada 
-->

<form method="post" action="bintang.php">
	<label for="bintang">Jumlah Bintang=</label>
	<input type="number" name="bintang">
	<br>
	<input type="submit">
</form>
